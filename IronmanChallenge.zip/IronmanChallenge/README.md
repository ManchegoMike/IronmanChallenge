# Ironman Challenge

A World of Warcraft addon to support the Ironman Challenge. This version is for Project Epoch or theoretically any other WotLK client.

Hardcore, no mail, no auction house, only white or gray gear, no talents, no primary professions, no potions, no healthstones, no food or scroll buffs, no external buffs, self-buff spells are OK.

The addon doesn't strictly disallow anything -- it just provides warnings to keep you on the right track.

Written by ManchegoMike ([Twitch](https://www.twitch.tv/ManchegoMike))

Include localization for German, Spanish, French, Italian, Russian, Korean, and Chinese (traditional).

## Usage

You can use the console command `/iron` or `/ironman`.
